package dao;

import java.sql.*;
import java.util.*;
import app.DB;

public class ItemDAO {

    public int buscarIdPorNome(String nome) throws Exception {
        String sql = "SELECT id FROM item WHERE nome = ?";
        try (Connection c = DB.conectar();
             PreparedStatement p = c.prepareStatement(sql)) {

            p.setString(1, nome);
            ResultSet rs = p.executeQuery();

            if (rs.next()) return rs.getInt("id");
        }
        return -1;
    }

    public int inserirRetornandoId(String nome, String tipo) throws Exception {
        String sql = "INSERT INTO item (nome, tipo) VALUES (?, ?)";

        try (Connection c = DB.conectar();
             PreparedStatement p = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            p.setString(1, nome);
            p.setString(2, tipo);
            p.executeUpdate();

            ResultSet rs = p.getGeneratedKeys();
            if (rs.next()) return rs.getInt(1);
        }
        return -1;
    }

    public List<String> listar() throws Exception {
        List<String> lista = new ArrayList<>();
        String sql = "SELECT * FROM item";

        try (Connection c = DB.conectar();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                lista.add(
                    rs.getInt("id") + " - " +
                    rs.getString("nome") + " (" +
                    rs.getString("tipo") + ")"
                );
            }
        }
        return lista;
    }
}
