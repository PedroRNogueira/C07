package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import app.DB;
import Missoes.Missao;

public class MissaoDAO {

    public void inserir(Missao m) throws Exception {
        String sql = "INSERT INTO missao (id, descricao) VALUES (?, ?)";
        try (Connection c = DB.conectar();
             PreparedStatement p = c.prepareStatement(sql)) {
            p.setInt(1, m.getId());
            p.setString(2, m.getDescricao());
            p.executeUpdate();
        }
    }

    public List<Missao> listar() throws Exception {
        List<Missao> lista = new ArrayList<>();
        String sql = "SELECT * FROM missao ORDER BY id";
        try (Connection c = DB.conectar();
             PreparedStatement p = c.prepareStatement(sql);
             ResultSet rs = p.executeQuery()) {
            while (rs.next()) {
                lista.add(new Missao(rs.getInt("id"), rs.getString("descricao")));
            }
        }
        return lista;
    }
}
