package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import app.DB;
import Entidades.Jogador;

public class JogadorDAO {

    public void inserir(Jogador j) throws Exception {
        String sql = "INSERT INTO jogador (nome, vida, ataque, experiencia, capacidade_inventario, mapa_atual, missao_atual, horario) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection c = DB.conectar();
             PreparedStatement p = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            p.setString(1, j.getNome());
            p.setInt(2, j.getVida());
            p.setInt(3, j.getAtaque());
            p.setInt(4, j.getExperiencia());
            p.setInt(5, j.getCapacidadeInventario());
            p.setInt(6, j.getMapaAtual());
            p.setInt(7, j.getMissaoAtual());
            p.setString(8, app.Relogio.getHorario());

            p.executeUpdate();

            ResultSet rs = p.getGeneratedKeys();
            if (rs.next()) {
                j.setId(rs.getInt(1));
            }
        }
    }

    public void atualizar(Jogador j) throws Exception {
        String sql = "UPDATE jogador SET nome=?, vida=?, ataque=?, experiencia=?, capacidade_inventario=?, mapa_atual=?, missao_atual=?, horario=? WHERE id=?";
        try (Connection c = DB.conectar();
             PreparedStatement p = c.prepareStatement(sql)) {

            p.setString(1, j.getNome());
            p.setInt(2, j.getVida());
            p.setInt(3, j.getAtaque());
            p.setInt(4, j.getExperiencia());
            p.setInt(5, j.getCapacidadeInventario());
            p.setInt(6, j.getMapaAtual());
            p.setInt(7, j.getMissaoAtual());
            p.setString(8, app.Relogio.getHorario());
            p.setInt(9, j.getId());

            p.executeUpdate();
        }
    }

    public void deletar(int id) throws Exception {
        String sql = "DELETE FROM jogador WHERE id=?";
        try (Connection c = DB.conectar();
             PreparedStatement p = c.prepareStatement(sql)) {
            p.setInt(1, id);
            p.executeUpdate();
        }
    }

    public Jogador buscarPorId(int id) throws Exception {
        String sql = "SELECT * FROM jogador WHERE id=?";
        try (Connection c = DB.conectar();
             PreparedStatement p = c.prepareStatement(sql)) {

            p.setInt(1, id);
            ResultSet rs = p.executeQuery();

            if (rs.next()) {
                Jogador j = new Jogador(
                        rs.getString("nome"),
                        rs.getInt("vida"),
                        rs.getInt("ataque")
                );
                j.setId(rs.getInt("id"));
                j.ganharExperiencia(rs.getInt("experiencia"));
                j.setCapacidadeInventario(rs.getInt("capacidade_inventario"));
                j.setMapaAtual(rs.getInt("mapa_atual"));
                j.setMissaoAtual(rs.getInt("missao_atual"));
                return j;
            }
        }
        return null;
    }

    public List<Jogador> listarTodos() throws Exception {
        List<Jogador> lista = new ArrayList<>();
        String sql = "SELECT * FROM jogador ORDER BY id";
        try (Connection c = DB.conectar();
             PreparedStatement p = c.prepareStatement(sql);
             ResultSet rs = p.executeQuery()) {

            while (rs.next()) {
                Jogador j = new Jogador(
                        rs.getString("nome"),
                        rs.getInt("vida"),
                        rs.getInt("ataque")
                );
                j.setId(rs.getInt("id"));
                j.ganharExperiencia(rs.getInt("experiencia"));
                j.setCapacidadeInventario(rs.getInt("capacidade_inventario"));
                j.setMapaAtual(rs.getInt("mapa_atual"));
                j.setMissaoAtual(rs.getInt("missao_atual"));
                lista.add(j);
            }
        }
        return lista;
    }
}
