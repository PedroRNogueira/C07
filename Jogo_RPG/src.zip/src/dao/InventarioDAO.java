package dao;

import java.sql.*;
import java.util.*;
import app.DB;

public class InventarioDAO {

    public void adicionarItem(int jogadorId, int itemId) throws Exception {
        String sql = "INSERT INTO inventario (jogador_id, item_id) VALUES (?, ?)";
        try (Connection c = DB.conectar();
             PreparedStatement p = c.prepareStatement(sql)) {

            p.setInt(1, jogadorId);
            p.setInt(2, itemId);
            p.executeUpdate();
        }
    }

    public void removerPorId(int invId) throws Exception {
        String sql = "DELETE FROM inventario WHERE id = ?";
        try (Connection c = DB.conectar();
             PreparedStatement p = c.prepareStatement(sql)) {

            p.setInt(1, invId);
            p.executeUpdate();
        }
    }

    public List<InventarioEntry> listarDetalhado(int jogadorId) throws Exception {

        List<InventarioEntry> itens = new ArrayList<>();

        String sql = "SELECT inv.id AS inv_id, i.id AS item_id, i.nome AS item_nome " +
                     "FROM inventario inv " +
                     "JOIN item i ON i.id = inv.item_id " +
                     "WHERE inv.jogador_id = ?";

        try (Connection c = DB.conectar();
             PreparedStatement p = c.prepareStatement(sql)) {

            p.setInt(1, jogadorId);
            ResultSet rs = p.executeQuery();

            while (rs.next()) {
                itens.add(new InventarioEntry(
                        rs.getInt("inv_id"),
                        rs.getInt("item_id"),
                        rs.getString("item_nome")
                ));
            }
        }
        return itens;
    }

    public static class InventarioEntry {
        public final int invId;
        public final int itemId;
        public final String itemNome;

        public InventarioEntry(int invId, int itemId, String itemNome) {
            this.invId = invId;
            this.itemId = itemId;
            this.itemNome = itemNome;
        }
    }
}
