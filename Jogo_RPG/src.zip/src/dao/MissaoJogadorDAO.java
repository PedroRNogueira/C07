package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import app.DB;

public class MissaoJogadorDAO {

    // inicia as 5 missões para um jogador (concluida = false)
    public void iniciarMissoesParaJogador(int jogadorId) throws Exception {
        String sql = "INSERT INTO missao_jogador (jogador_id, missao_id, concluida) VALUES (?, ?, ?)";
        try (Connection c = DB.conectar();
             PreparedStatement p = c.prepareStatement(sql)) {
            for (int i = 1; i <= 5; i++) {
                p.setInt(1, jogadorId);
                p.setInt(2, i);
                p.setBoolean(3, false);
                p.executeUpdate();
            }
        }
    }

    // marcar missão concluída
    public void concluirMissao(int jogadorId, int missaoId) throws Exception {
        String sql = "UPDATE missao_jogador SET concluida = true WHERE jogador_id = ? AND missao_id = ?";
        try (Connection c = DB.conectar();
             PreparedStatement p = c.prepareStatement(sql)) {
            p.setInt(1, jogadorId);
            p.setInt(2, missaoId);
            p.executeUpdate();
        }
    }

    // listar status de missões do jogador (retorna boolean[] length 5, index 0 -> missao 1)
    public boolean[] listarStatus(int jogadorId) throws Exception {
        boolean[] status = new boolean[5];
        String sql = "SELECT missao_id, concluida FROM missao_jogador WHERE jogador_id = ? ORDER BY missao_id";
        try (Connection c = DB.conectar();
             PreparedStatement p = c.prepareStatement(sql)) {
            p.setInt(1, jogadorId);
            ResultSet rs = p.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("missao_id");
                boolean concl = rs.getBoolean("concluida");
                if (id >= 1 && id <= 5) status[id - 1] = concl;
            }
        }
        return status;
    }

    // listar para exibição (JOIN)
    public List<String> listarMissoesComStatus(int jogadorId) throws Exception {
        List<String> lista = new ArrayList<>();
        String sql = "SELECT m.descricao, mj.concluida FROM missao_jogador mj JOIN missao m ON m.id = mj.missao_id WHERE mj.jogador_id = ? ORDER BY mj.missao_id";
        try (Connection c = DB.conectar();
             PreparedStatement p = c.prepareStatement(sql)) {
            p.setInt(1, jogadorId);
            ResultSet rs = p.executeQuery();
            while (rs.next()) {
                lista.add(rs.getString("descricao") + " - " + (rs.getBoolean("concluida") ? "OK" : "Pendente"));
            }
        }
        return lista;
    }
}
