package app;

import dao.*;
import Entidades.Jogador;

import java.sql.*;
import java.util.Scanner;
import java.util.List;

public class MenuRPG {

    private static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        JogadorDAO jogadorDAO = new JogadorDAO();
        ItemDAO itemDAO = new ItemDAO();
        InventarioDAO inventarioDAO = new InventarioDAO();
        MissaoJogadorDAO missaoJogadorDAO = new MissaoJogadorDAO();

        while (true) {

            System.out.println("\n===== MENU RPG (CRUD + JOINS) =====");
            System.out.println("1 - Inserir jogador");
            System.out.println("2 - Atualizar jogador");
            System.out.println("3 - Deletar jogador");
            System.out.println("4 - Listar jogadores");

            System.out.println("5 - Inserir item");
            System.out.println("6 - Listar itens");

            System.out.println("7 - Adicionar item ao inventário");
            System.out.println("8 - Listar inventário de um jogador");

            System.out.println("9 - Listar jogadores e MISSÃO ATUAL (computed from missao_jogador)");
            System.out.println("11 - Mostrar detalhes (Inventário + Missões) de um jogador");

            System.out.println("0 - Sair");
            System.out.print("Escolha: ");

            int op = lerInt();

            try {

                switch (op) {

                    case 1 -> inserirJogador(jogadorDAO);
                    case 2 -> atualizarJogador(jogadorDAO);
                    case 3 -> deletarJogador(jogadorDAO);
                    case 4 -> listarJogadores(jogadorDAO);

                    case 5 -> inserirItem(itemDAO);
                    case 6 -> listarItens(itemDAO);

                    case 7 -> adicionarItemInventario(inventarioDAO);
                    case 8 -> listarInventario(inventarioDAO);

                    case 9 -> listarJogadoresComMissaoAtual(); // CORRIGIDO
                    case 11 -> mostrarDetalhesJogador(inventarioDAO, missaoJogadorDAO);

                    case 0 -> {
                        System.out.println("Saindo...");
                        return;
                    }

                    default -> System.out.println("Opção inválida!");
                }

            } catch (Exception e) {
                System.out.println("Erro: " + e.getMessage());
            }
        }
    }

    private static int lerInt() {
        while (true) {
            try {
                return Integer.parseInt(sc.nextLine());
            } catch (Exception e) {
                System.out.print("Número inválido, tente novamente: ");
            }
        }
    }

    // ------------------------------
    // CRUD Jogador
    // ------------------------------
    private static void inserirJogador(JogadorDAO dao) throws Exception {
        System.out.print("Nome do jogador: ");
        String nome = sc.nextLine();

        Jogador j = new Jogador(nome, 100, 10);
        dao.inserir(j);

        // iniciar missões no BD
        MissaoJogadorDAO mj = new MissaoJogadorDAO();
        mj.iniciarMissoesParaJogador(j.getId());

        System.out.println("Jogador criado com ID: " + j.getId());
    }

    private static void atualizarJogador(JogadorDAO dao) throws Exception {
        System.out.print("ID do jogador: ");
        int id = lerInt();

        Jogador j = dao.buscarPorId(id);
        if (j == null) {
            System.out.println("Jogador não existe.");
            return;
        }

        System.out.print("Novo nome: ");
        j.setNome(sc.nextLine());

        System.out.print("Nova vida: ");
        j.setVida(lerInt());

        dao.atualizar(j);
        System.out.println("Jogador atualizado!");
    }

    private static void deletarJogador(JogadorDAO dao) throws Exception {
        System.out.print("ID para deletar: ");
        int id = lerInt();
        dao.deletar(id);
        System.out.println("Jogador deletado!");
    }

    private static void listarJogadores(JogadorDAO dao) throws Exception {
        var lista = dao.listarTodos();
        if (lista.isEmpty()) {
            System.out.println("Nenhum jogador cadastrado.");
            return;
        }
        lista.forEach(j ->
                System.out.println(j.getId() + " - " + j.getNome() + " | XP: " + j.getExperiencia())
        );
    }

    // ------------------------------
    // CRUD Item
    // ------------------------------
    private static void inserirItem(ItemDAO dao) throws Exception {
        System.out.print("Nome do item: ");
        String nome = sc.nextLine();

        System.out.print("Tipo do item: ");
        String tipo = sc.nextLine();

        int id = dao.inserirRetornandoId(nome, tipo);
        System.out.println("Item criado com ID: " + id);
    }

    private static void listarItens(ItemDAO dao) throws Exception {
        var lista = dao.listar();
        lista.forEach(System.out::println);
    }

    // ------------------------------
    // Inventário
    // ------------------------------
    private static void adicionarItemInventario(InventarioDAO dao) throws Exception {
        System.out.print("ID jogador: ");
        int jogadorId = lerInt();

        System.out.print("ID item: ");
        int itemId = lerInt();

        dao.adicionarItem(jogadorId, itemId);
        System.out.println("Item adicionado!");
    }

    private static void listarInventario(InventarioDAO dao) throws Exception {
        System.out.print("ID jogador: ");
        int jogadorId = lerInt();

        var itens = dao.listarDetalhado(jogadorId);

        if (itens.isEmpty()) {
            System.out.println("Inventário vazio.");
            return;
        }

        for (var it : itens) {
            System.out.println("InvID: " + it.invId +
                    " | ItemID: " + it.itemId +
                    " | Nome: " + it.itemNome);
        }
    }

    // ------------------------------
    // OPÇÃO 9 — LISTAR JOGADORES E MISSÃO ATUAL (computed)
    // ------------------------------
    private static void listarJogadoresComMissaoAtual() {
        String sql = ""
            + "SELECT j.id AS jogador_id, j.nome AS jogador_nome, j.mapa_atual, pm.prox_missao, m.descricao AS prox_missao_desc\n"
            + "FROM jogador j\n"
            + "LEFT JOIN (\n"
            + "    SELECT jogador_id, MIN(missao_id) AS prox_missao\n"
            + "    FROM missao_jogador\n"
            + "    WHERE concluida = FALSE\n"
            + "    GROUP BY jogador_id\n"
            + ") pm ON pm.jogador_id = j.id\n"
            + "LEFT JOIN missao m ON m.id = pm.prox_missao\n"
            + "ORDER BY j.id;";

        try (Connection c = app.DB.conectar();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            System.out.println("\nID | Nome | MapaAtual | MissaoAtual(ID) | MissaoAtual(Descrição)");
            System.out.println("---------------------------------------------------------------");

            int rows = 0;
            while (rs.next()) {
                int id = rs.getInt("jogador_id");
                String nome = rs.getString("jogador_nome");
                int mapa = rs.getInt("mapa_atual");
                Integer proxMissao = (Integer) rs.getObject("prox_missao"); // may be null
                String desc = rs.getString("prox_missao_desc");

                String missaoText;
                if (proxMissao == null) missaoText = "TODAS CONCLUÍDAS";
                else missaoText = proxMissao + " - " + (desc == null ? "(sem descrição)" : desc);

                System.out.printf("%d | %s | %d | %s%n", id, nome, mapa, missaoText);
                rows++;
            }
            if (rows == 0) System.out.println("[nenhum jogador encontrado]");

        } catch (Exception e) {
            System.out.println("Erro ao listar jogadores/missão atual: " + e.getMessage());
        }
    }

    // ------------------------------
    // OPÇÃO 11 — Mostrar detalhes do jogador (inventário + missões)
    // ------------------------------
    private static void mostrarDetalhesJogador(InventarioDAO invDao, MissaoJogadorDAO mjDao) {
        System.out.print("ID jogador: ");
        int jogadorId = lerInt();

        try {
            System.out.println("\n--- Inventário ---");
            var itens = invDao.listarDetalhado(jogadorId);
            if (itens.isEmpty()) System.out.println("[Inventário vazio]");
            else itens.forEach(e -> System.out.println("InvID: " + e.invId + " | ItemID: " + e.itemId + " | Nome: " + e.itemNome));

            System.out.println("\n--- Missões ---");
            var missoes = mjDao.listarMissoesComStatus(jogadorId);
            if (missoes.isEmpty()) System.out.println("[Nenhuma missão cadastrada para esse jogador]");
            else missoes.forEach(System.out::println);

        } catch (Exception e) {
            System.out.println("Erro ao mostrar detalhes do jogador: " + e.getMessage());
        }
    }

    // ------------------------------
    // utilitário genérico para exibir query (mantido)
    // ------------------------------
    private static void executarEPrint(String sql) {
        try (Connection c = DB.conectar();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            ResultSetMetaData md = rs.getMetaData();
            int col = md.getColumnCount();

            System.out.println("\n-----------------------------------------");
            System.out.println(sql);
            System.out.println("-----------------------------------------");

            while (rs.next()) {
                for (int i = 1; i <= col; i++) {
                    System.out.print(md.getColumnName(i) + "=" + rs.getString(i));
                    if (i < col) System.out.print(" | ");
                }
                System.out.println();
            }

        } catch (Exception e) {
            System.out.println("Erro SQL: " + e.getMessage());
        }
    }
}
